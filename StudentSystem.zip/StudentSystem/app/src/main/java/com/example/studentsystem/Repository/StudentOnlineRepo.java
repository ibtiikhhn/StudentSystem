package com.example.studentsystem.Repository;

public class StudentOnlineRepo {
}
