package com.example.studentsystem.UI;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.studentsystem.LocalDatabase.StudentModel;
import com.example.studentsystem.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class StudentsAdapter extends RecyclerView.Adapter<StudentsAdapter.StudentsHolder> {

    List<StudentModel> arrayList = new ArrayList<>();

     public void setArrayList(List<StudentModel> arrayList) {
        this.arrayList = arrayList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public StudentsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_student_recycler, parent, false);
        StudentsHolder studentsHolder = new StudentsHolder(view);
        return studentsHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull StudentsHolder holder, int position) {
        holder.stdName.setText(arrayList.get(position).getName());
        holder.stdReg.setText(arrayList.get(position).getRegistration());
//        holder.stdImage.setImageBitmap();
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class StudentsHolder extends RecyclerView.ViewHolder {
        ImageView stdImage;
        ImageView stdMore;
        TextView stdName;
        TextView stdReg;
        public StudentsHolder(@NonNull View itemView) {
            super(itemView);

            stdImage = itemView.findViewById(R.id.stdImage);
            stdMore = itemView.findViewById(R.id.stdMore);
            stdName = itemView.findViewById(R.id.stdName);
            stdReg = itemView.findViewById(R.id.stdReg);
        }
    }
}
