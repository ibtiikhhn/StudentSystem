package com.example.studentsystem.LocalDatabase;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "student_table")
public class StudentModel {

    @PrimaryKey(autoGenerate = true)
    int id;

    String name;

    int age;

    String degree;

    String department;

    String registration;

    public StudentModel(String name, int age, String degree, String department, String registration) {
        this.name = name;
        this.age = age;
        this.degree = degree;
        this.department = department;
        this.registration = registration;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getRegistration() {
        return registration;
    }

    public int getAge() {
        return age;
    }

    public String getDegree() {
        return degree;
    }

    public String getDepartment() {
        return department;
    }

}
