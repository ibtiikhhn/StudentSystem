package com.example.studentsystem.UI;

import android.os.Bundle;
import android.util.Log;

import com.example.studentsystem.LocalDatabase.StudentModel;
import com.example.studentsystem.R;

import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class StudentsActivity extends AppCompatActivity {

    StudentsViewModel studentsViewModel;

    RecyclerView recyclerView;
    StudentsAdapter studentsAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        studentsViewModel = ViewModelProviders.of(this).get(StudentsViewModel.class);
        studentsViewModel.getStudentsList().observe(this, new Observer<List<StudentModel>>() {
            @Override
            public void onChanged(List<StudentModel> studentModels) {
                studentsAdapter.setArrayList(studentModels);
//                studentModels.get(0).getName().toString();
                Log.i("Kuttidia", "onChanged: "+studentModels.get(0).getName());
            }
        });

    }

    public void initViews() {
        recyclerView = findViewById(R.id.stdRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        studentsAdapter = new StudentsAdapter();
        recyclerView.setAdapter(studentsAdapter);
    }
}
